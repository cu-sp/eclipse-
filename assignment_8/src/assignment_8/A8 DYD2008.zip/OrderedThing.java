package assignment_8;

public abstract class OrderedThing{}
