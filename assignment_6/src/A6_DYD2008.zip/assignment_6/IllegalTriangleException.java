package assignment_6;

public class IllegalTriangleException extends Exception {
	
}
